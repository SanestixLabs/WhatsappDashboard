import React, { useState, useRef, useEffect } from 'react';
import { format } from 'date-fns';
import { useMessageStore, useConversationStore } from '../../store';
import toast from 'react-hot-toast';

export default function ChatWindow({ conversation }) {
  const [text, setText] = useState('');
  const bottomRef = useRef(null);
  const inputRef = useRef(null);
  const { messagesByConv, sending, sendMessage } = useMessageStore();
  const { toggleAutomation, closeConversation } = useConversationStore();
  const messages = messagesByConv[conversation.id] || [];

  useEffect(() => { bottomRef.current?.scrollIntoView({ behavior:'smooth' }); }, [messages.length]);
  useEffect(() => { inputRef.current?.focus(); setText(''); }, [conversation.id]);

  const handleSend = async () => {
    const t = text.trim();
    if (!t || sending) return;
    setText('');
    const r = await sendMessage(conversation.id, t);
    if (!r?.ok) { toast.error(r?.error || 'Failed to send'); setText(t); }
  };

  const handleKey = (e) => { if (e.key==='Enter'&&!e.shiftKey){ e.preventDefault(); handleSend(); } };
  const autoResize = (e) => { e.target.style.height='auto'; e.target.style.height=Math.min(e.target.scrollHeight,120)+'px'; };

  const isExpired = conversation.session_expires_at ? new Date(conversation.session_expires_at)<=new Date() : true;
  const aiOn = conversation.automation_enabled;

  const name = conversation.contact_name || conversation.phone_number;
  const initials = conversation.contact_name
    ? conversation.contact_name.split(' ').map(n=>n[0]).join('').toUpperCase().slice(0,2)
    : conversation.phone_number?.slice(-2);

  const avatarColors = ['linear-gradient(135deg,#6366f1,#8b5cf6)','linear-gradient(135deg,#f97316,#fbbf24)','linear-gradient(135deg,#ec4899,#f43f5e)','linear-gradient(135deg,#14b8a6,#22d3ee)','linear-gradient(135deg,#8b5cf6,#6366f1)','linear-gradient(135deg,#10b981,#14b8a6)'];
  const avatarColor = avatarColors[(name||'').charCodeAt(0) % avatarColors.length];

  const grouped = messages.reduce((acc, msg) => {
    const d = new Date(msg.timestamp||msg.created_at);
    const today = new Date(); const yesterday = new Date(today); yesterday.setDate(today.getDate()-1);
    let label = d.toDateString()===today.toDateString()?'Today':d.toDateString()===yesterday.toDateString()?'Yesterday':format(d,'MMMM d, yyyy');
    if (!acc[label]) acc[label]=[];
    acc[label].push(msg); return acc;
  }, {});

  return (
    <div style={s.root}>
      {/* Header */}
      <div style={s.head}>
        <div style={{...s.av,background:avatarColor,width:'40px',height:'40px',fontSize:'13px',flexShrink:0}}>{initials}</div>
        <div style={s.info}>
          <div style={s.name}>{name}</div>
          <div style={s.sub}>
            <span style={{width:'6px',height:'6px',borderRadius:'50%',background:isExpired?'#f43f5e':'#22d3ee',animation:isExpired?'none':'pulse 2s infinite',display:'inline-block'}}/>
            <span style={{color:isExpired?'#f43f5e':'#22d3ee',fontSize:'11.5px'}}>{isExpired?'Session expired':'Active session'}</span>
            <span style={{color:'#3d5470',fontSize:'11.5px'}}>{conversation.phone_number}</span>
          </div>
        </div>
        <div style={s.actions}>
          <HdrBtn title="Search"><SearchIcon/></HdrBtn>
          {/* AI Toggle */}
          <div style={{...s.aiWrap,...(aiOn?s.aiWrapOn:{})}}
            onClick={()=>toggleAutomation(conversation.id,!aiOn)} title={aiOn?'Disable AI':'Enable AI'}>
            <BotIcon/>
            <span style={{fontSize:'11px',fontWeight:'600',color:aiOn?'#22d3ee':'#3d5470',transition:'color .2s'}}>AI Agent</span>
            <div style={{...s.track,background:aiOn?'#22d3ee':'#1e3048'}}>
              <div style={{...s.knob,left:aiOn?'16px':'2px'}}/>
            </div>
            <span style={{fontSize:'10px',fontWeight:'700',color:aiOn?'#22d3ee':'#3d5470',minWidth:'20px'}}>{aiOn?'ON':'OFF'}</span>
          </div>
          <HdrBtn title="Close" onClick={()=>closeConversation(conversation.id)}><CloseIcon/></HdrBtn>
        </div>
      </div>

      {/* Messages */}
      <div style={s.msgs}>
        <div style={s.watermark}>
          <WaWatermark/><p style={{fontSize:'14px',fontWeight:'700',color:'#1e3048',marginTop:'8px'}}>Sanestix Flow</p>
          <p style={{fontSize:'12px',color:'#1e3048'}}>WhatsApp automation</p>
        </div>
        {messages.length===0 && <div style={s.noMsg}>No messages yet</div>}
        {Object.entries(grouped).map(([date,msgs])=>(
          <div key={date}>
            <div style={s.dateSep}><div style={s.dateLine}/><span style={s.dateLbl}>{date}</span><div style={s.dateLine}/></div>
            {msgs.map(msg=><Bubble key={msg.id} msg={msg} initials={initials} avatarColor={avatarColor}/>)}
          </div>
        ))}
        <div ref={bottomRef}/>
      </div>

      {/* Banners */}
      {aiOn && !isExpired && (
        <div style={{...s.banner,background:'rgba(34,211,238,.05)',borderTop:'1px solid rgba(34,211,238,.1)',color:'#22d3ee'}}>
          <BotIcon/> AI Agent is active — automatically replying to this conversation.
        </div>
      )}
      {!aiOn && !isExpired && (
        <div style={{...s.banner,background:'rgba(245,158,11,.05)',borderTop:'1px solid rgba(245,158,11,.15)',color:'#f59e0b'}}>
          <ManualIcon/> Manual mode — AI is paused. You're handling this conversation.
        </div>
      )}
      {isExpired && (
        <div style={{...s.banner,background:'rgba(244,63,94,.05)',borderTop:'1px solid rgba(244,63,94,.15)',color:'#f43f5e'}}>
          <WarnIcon/> 24-hour session expired — send a template message to resume.
        </div>
      )}

      {/* Composer */}
      <div style={s.composer}>
        <button style={s.toolBtn} title="Emoji"><EmojiIcon/></button>
        <div style={s.inputBox}>
          <textarea ref={inputRef} value={text} onChange={e=>{setText(e.target.value);autoResize(e);}}
            onKeyDown={handleKey} disabled={isExpired} rows={1}
            placeholder={isExpired?'Session expired…':'Type a message…'}
            style={{...s.textarea,opacity:isExpired?.4:1,cursor:isExpired?'not-allowed':'text'}}/>
        </div>
        <button style={s.toolBtn} title="Attach"><AttachIcon/></button>
        <button onClick={handleSend} disabled={!text.trim()||sending||isExpired} style={{
          ...s.sendBtn,
          background:text.trim()&&!isExpired?'linear-gradient(135deg,#22d3ee,#0891b2)':'#1e3048',
          boxShadow:text.trim()&&!isExpired?'0 0 16px rgba(34,211,238,.3)':'none',
          cursor:text.trim()&&!isExpired?'pointer':'not-allowed',
        }}>
          {sending?<Spinner/>:<SendIcon active={!!text.trim()&&!isExpired}/>}
        </button>
      </div>
    </div>
  );
}

function Bubble({ msg, initials, avatarColor }) {
  const out = msg.direction==='outgoing';
  const time = format(new Date(msg.timestamp||msg.created_at),'HH:mm');
  return (
    <div className="msg-appear" style={{...s.msgRow,justifyContent:out?'flex-end':'flex-start'}}>
      {!out && <div style={{...s.av,background:avatarColor,width:'28px',height:'28px',fontSize:'10px',flexShrink:0,alignSelf:'flex-end'}}>{initials}</div>}
      <div style={{display:'flex',flexDirection:'column',gap:'2px'}}>
        <div style={out?s.bubbleOut:s.bubbleIn}>{msg.content}</div>
        <div style={s.meta}>
          <span style={{fontSize:'9.5px',color:out?'rgba(255,255,255,.3)':'#3d5470',fontFamily:"'DM Mono',monospace"}}>{time}</span>
          {out && <TickIcon status={msg.status}/>}
        </div>
      </div>
      {out && <div style={{width:'28px',flexShrink:0}}/>}
    </div>
  );
}

const TickIcon=({status})=>{
  if(status==='read') return <svg width="16" height="10" viewBox="0 0 24 11" fill="none"><path d="M1 5.5L5 9.5L15 1.5" stroke="#22d3ee" strokeWidth="2" strokeLinecap="round"/><path d="M5 5.5L9 9.5L15 3.5" stroke="#22d3ee" strokeWidth="2" strokeLinecap="round"/></svg>;
  if(status==='delivered') return <svg width="16" height="10" viewBox="0 0 24 11" fill="none"><path d="M1 5.5L5 9.5L15 1.5" stroke="rgba(255,255,255,.4)" strokeWidth="2" strokeLinecap="round"/><path d="M5 5.5L9 9.5L15 3.5" stroke="rgba(255,255,255,.4)" strokeWidth="2" strokeLinecap="round"/></svg>;
  return <svg width="14" height="10" viewBox="0 0 14 11" fill="none"><path d="M1 5L5 9L13 1" stroke="rgba(255,255,255,.3)" strokeWidth="2" strokeLinecap="round"/></svg>;
};

const HdrBtn=({children,onClick,title})=><button onClick={onClick} title={title} style={s.hdrBtn}>{children}</button>;
const SearchIcon=()=><svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.9"><circle cx="11" cy="11" r="8"/><path d="M21 21l-4.35-4.35"/></svg>;
const CloseIcon=()=><svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M18 6L6 18M6 6l12 12"/></svg>;
const BotIcon=()=><svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" style={{flexShrink:0}}><rect x="3" y="8" width="18" height="12" rx="2"/><path d="M9 8V6a3 3 0 016 0v2"/><path d="M9 14h.01M15 14h.01" strokeLinecap="round"/></svg>;
const WarnIcon=()=><svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" style={{flexShrink:0}}><path d="M10.29 3.86L1.82 18a2 2 0 001.71 3h16.94a2 2 0 001.71-3L13.71 3.86a2 2 0 00-3.42 0z"/><line x1="12" y1="9" x2="12" y2="13"/><line x1="12" y1="17" x2="12.01" y2="17"/></svg>;
const ManualIcon=()=><svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" style={{flexShrink:0}}><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/></svg>;
const EmojiIcon=()=><svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8"><circle cx="12" cy="12" r="10"/><path d="M8 14s1.5 2 4 2 4-2 4-2"/><line x1="9" y1="9" x2="9.01" y2="9"/><line x1="15" y1="9" x2="15.01" y2="9"/></svg>;
const AttachIcon=()=><svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8"><path d="M21.44 11.05l-9.19 9.19a6 6 0 01-8.49-8.49l9.19-9.19a4 4 0 015.66 5.66l-9.2 9.19a2 2 0 01-2.83-2.83l8.49-8.48"/></svg>;
const SendIcon=({active})=><svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke={active?'#020617':'#3d5470'} strokeWidth="2.2"><line x1="22" y1="2" x2="11" y2="13"/><polygon points="22 2 15 22 11 13 2 9 22 2"/></svg>;
const WaWatermark=()=><svg width="44" height="44" viewBox="0 0 24 24" fill="none"><path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51a6.08 6.08 0 00-.57-.01c-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347z" fill="#1e3048"/><path d="M5.077 18.347l.892-3.244a8.357 8.357 0 01-1.12-4.232C4.852 6.26 8.113 3 12.124 3c1.948.001 3.778.76 5.151 2.138a7.247 7.247 0 012.124 5.155c-.002 4.012-3.263 7.272-7.272 7.272a7.266 7.266 0 01-3.475-.883l-3.575.865z" stroke="#1e3048" strokeWidth="1.5" fill="none"/></svg>;
const Spinner=()=><span style={{width:'18px',height:'18px',border:'2px solid rgba(255,255,255,.2)',borderTopColor:'#fff',borderRadius:'50%',display:'inline-block',animation:'spin .7s linear infinite'}}/>;

const s={
  root:{flex:1,display:'flex',flexDirection:'column',overflow:'hidden',background:'#080c12'},
  head:{display:'flex',alignItems:'center',gap:'12px',padding:'12px 20px',background:'#0d1420',borderBottom:'1px solid rgba(255,255,255,0.06)',flexShrink:0},
  av:{borderRadius:'50%',display:'flex',alignItems:'center',justifyContent:'center',fontWeight:'700',color:'white'},
  info:{flex:1,minWidth:0},
  name:{fontSize:'15px',fontWeight:'700',letterSpacing:'-.3px',color:'#f0f6ff',whiteSpace:'nowrap',overflow:'hidden',textOverflow:'ellipsis'},
  sub:{display:'flex',alignItems:'center',gap:'6px',marginTop:'2px'},
  actions:{display:'flex',alignItems:'center',gap:'8px',flexShrink:0},
  hdrBtn:{width:'34px',height:'34px',borderRadius:'9px',border:'1px solid rgba(255,255,255,0.06)',background:'transparent',color:'#3d5470',cursor:'pointer',display:'flex',alignItems:'center',justifyContent:'center',transition:'all .15s'},
  aiWrap:{display:'flex',alignItems:'center',gap:'7px',padding:'6px 12px',borderRadius:'20px',border:'1px solid rgba(255,255,255,0.06)',background:'#111c2e',cursor:'pointer',transition:'all .2s',userSelect:'none'},
  aiWrapOn:{borderColor:'rgba(34,211,238,.35)',background:'rgba(34,211,238,.1)'},
  track:{width:'30px',height:'16px',borderRadius:'8px',position:'relative',transition:'background .2s',flexShrink:0},
  knob:{width:'12px',height:'12px',background:'white',borderRadius:'50%',position:'absolute',top:'2px',transition:'left .2s',boxShadow:'0 1px 3px rgba(0,0,0,.3)'},
  msgs:{flex:1,overflowY:'auto',padding:'20px 60px',display:'flex',flexDirection:'column',gap:'2px',position:'relative',background:'#080c12',backgroundImage:'radial-gradient(ellipse at 15% 25%,rgba(34,211,238,.03) 0%,transparent 55%),radial-gradient(ellipse at 85% 75%,rgba(8,145,178,.04) 0%,transparent 55%)'},
  watermark:{position:'absolute',top:'50%',left:'50%',transform:'translate(-50%,-50%)',display:'flex',flexDirection:'column',alignItems:'center',opacity:.6,pointerEvents:'none',userSelect:'none'},
  noMsg:{textAlign:'center',color:'#1e3048',fontSize:'13px',marginTop:'60px'},
  dateSep:{display:'flex',alignItems:'center',gap:'10px',margin:'14px 0 10px'},
  dateLine:{flex:1,height:'1px',background:'rgba(255,255,255,0.06)'},
  dateLbl:{fontSize:'10.5px',color:'#3d5470',background:'#111c2e',border:'1px solid rgba(255,255,255,0.06)',padding:'3px 12px',borderRadius:'20px',fontFamily:"'DM Mono',monospace",whiteSpace:'nowrap'},
  msgRow:{display:'flex',gap:'8px',maxWidth:'62%',marginBottom:'2px'},
  bubbleIn:{padding:'9px 13px',borderRadius:'16px',borderBottomLeftRadius:'4px',background:'#111c2e',border:'1px solid rgba(255,255,255,0.06)',fontSize:'13.5px',lineHeight:'1.55',color:'#f0f6ff',wordBreak:'break-word',whiteSpace:'pre-wrap'},
  bubbleOut:{padding:'9px 13px',borderRadius:'16px',borderBottomRightRadius:'4px',background:'linear-gradient(135deg,#164e63,#0e7490)',fontSize:'13.5px',lineHeight:'1.55',color:'#fff',wordBreak:'break-word',whiteSpace:'pre-wrap',boxShadow:'0 2px 16px rgba(14,116,144,.25)'},
  meta:{display:'flex',alignItems:'center',gap:'4px',justifyContent:'flex-end',padding:'0 2px'},
  banner:{display:'flex',alignItems:'center',gap:'8px',padding:'8px 20px',fontSize:'12px',flexShrink:0},
  composer:{padding:'12px 16px',background:'#0d1420',borderTop:'1px solid rgba(255,255,255,0.06)',display:'flex',alignItems:'flex-end',gap:'8px',flexShrink:0},
  toolBtn:{width:'36px',height:'36px',borderRadius:'9px',border:'1px solid rgba(255,255,255,0.06)',background:'transparent',color:'#3d5470',cursor:'pointer',display:'flex',alignItems:'center',justifyContent:'center',transition:'all .15s',flexShrink:0},
  inputBox:{flex:1,background:'#111c2e',border:'1px solid rgba(255,255,255,0.06)',borderRadius:'16px',padding:'10px 14px',transition:'border-color .2s,box-shadow .2s'},
  textarea:{width:'100%',background:'transparent',border:'none',outline:'none',color:'#f0f6ff',fontSize:'13.5px',lineHeight:'1.5',minHeight:'22px',maxHeight:'120px',overflowY:'auto'},
  sendBtn:{width:'40px',height:'40px',borderRadius:'50%',border:'none',display:'flex',alignItems:'center',justifyContent:'center',transition:'all .15s',flexShrink:0},
};
