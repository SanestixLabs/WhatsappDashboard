import React, { useState } from 'react';
import { formatDistanceToNow } from 'date-fns';
import { useConversationStore } from '../../store';

export default function ConversationList({ conversations, activeId, onSelect }) {
  const [search, setSearch] = useState('');
  const [filter, setFilter] = useState('open');
  const { fetchConversations, total } = useConversationStore();

  const handleFilter = (f) => { setFilter(f); fetchConversations({ status: f }); };

  const getName = (conv) => conv.contact_name || conv.phone_number;
  const getInitials = (conv) => {
    if (conv.contact_name) return conv.contact_name.split(' ').map(n=>n[0]).join('').toUpperCase().slice(0,2);
    return conv.phone_number?.slice(-2);
  };

  const filtered = search
    ? conversations.filter(c => getName(c)?.toLowerCase().includes(search.toLowerCase()) || c.phone_number?.includes(search))
    : conversations;

  const avatarColors = ['linear-gradient(135deg,#6366f1,#8b5cf6)','linear-gradient(135deg,#f97316,#fbbf24)','linear-gradient(135deg,#ec4899,#f43f5e)','linear-gradient(135deg,#14b8a6,#22d3ee)','linear-gradient(135deg,#8b5cf6,#6366f1)','linear-gradient(135deg,#10b981,#14b8a6)'];
  const getColor = (name) => avatarColors[(name||'').charCodeAt(0) % avatarColors.length];

  const timeAgo = (t) => {
    if (!t) return '';
    try {
      return formatDistanceToNow(new Date(t), {addSuffix:false})
        .replace('about ','').replace(' minutes','m').replace(' minute','m')
        .replace(' hours','h').replace(' hour','h').replace(' days','d').replace(' day','d')
        .replace('less than a m','1m');
    } catch { return ''; }
  };

  return (
    <div style={s.root}>
      <div style={s.head}>
        <div style={s.headTop}>
          <h2 style={s.title}>Chats</h2>
          <span style={s.badge}>{total} open</span>
        </div>
        <div style={s.searchWrap}>
          <SearchIcon/>
          <input value={search} onChange={e=>setSearch(e.target.value)}
            placeholder="Search conversations…" style={s.search}
            onFocus={e=>e.target.style.borderColor='#22d3ee'}
            onBlur={e=>e.target.style.borderColor='rgba(255,255,255,0.06)'}/>
          {search && <button onClick={()=>setSearch('')} style={s.clearBtn}><ClearIcon/></button>}
        </div>
        <div style={s.tabs}>
          {['open','pending','closed'].map(f=>(
            <button key={f} onClick={()=>handleFilter(f)}
              style={{...s.tab,...(filter===f?s.tabActive:{})}}>
              {f.charAt(0).toUpperCase()+f.slice(1)}
              {filter===f && <div style={s.tabBar}/>}
            </button>
          ))}
        </div>
      </div>

      <div style={s.list}>
        {filtered.length===0 ? (
          <div style={s.empty}><EmptyIcon/><p>No {filter} conversations</p></div>
        ) : filtered.map((conv, i) => {
          const name = getName(conv);
          const isActive = conv.id === activeId;
          const preview = conv.last_message ? (conv.last_message_direction==='outgoing'?'✓ ':'')+conv.last_message : 'No messages yet';
          return (
            <button key={conv.id} className="conv-appear" onClick={()=>onSelect(conv)}
              style={{...s.item,...(isActive?s.itemActive:{}),animationDelay:`${i*0.03}s`}}>
              {isActive && <div style={s.activeBar}/>}
              <div style={{position:'relative',flexShrink:0}}>
                <div style={{...s.av,background:getColor(name)}}>{getInitials(conv)}</div>
                {conv.automation_enabled && <div style={s.aiDot} title="AI Active"/>}
              </div>
              <div style={s.body}>
                <div style={s.itemName}>{name}</div>
                <div style={s.preview}>{preview}</div>
              </div>
              <div style={s.right}>
                <span style={s.time}>{timeAgo(conv.last_message_at)}</span>
                {conv.unread_count > 0
                  ? <span style={s.unread}>{conv.unread_count > 99 ? '99+' : conv.unread_count}</span>
                  : conv.automation_enabled
                    ? <span style={s.aiChip}>AI</span>
                    : null
                }
              </div>
            </button>
          );
        })}
      </div>
    </div>
  );
}

const SearchIcon=()=><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="#3d5470" strokeWidth="2" style={{position:'absolute',left:'11px',pointerEvents:'none'}}><circle cx="11" cy="11" r="8"/><path d="M21 21l-4.35-4.35"/></svg>;
const ClearIcon=()=><svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5"><path d="M18 6L6 18M6 6l12 12"/></svg>;
const EmptyIcon=()=><svg width="36" height="36" viewBox="0 0 24 24" fill="none" stroke="#1e3048" strokeWidth="1.5" style={{marginBottom:'8px'}}><path d="M21 15a2 2 0 01-2 2H7l-4 4V5a2 2 0 012-2h14a2 2 0 012 2z"/></svg>;

const s={
  root:{width:'300px',flexShrink:0,background:'#0d1420',borderRight:'1px solid rgba(255,255,255,0.06)',display:'flex',flexDirection:'column',overflow:'hidden'},
  head:{padding:'18px 16px 0',flexShrink:0},
  headTop:{display:'flex',alignItems:'center',justifyContent:'space-between',marginBottom:'14px'},
  title:{fontSize:'18px',fontWeight:'700',letterSpacing:'-.4px',color:'#f0f6ff'},
  badge:{background:'rgba(34,211,238,0.12)',color:'#22d3ee',fontSize:'10px',fontWeight:'700',padding:'3px 9px',borderRadius:'20px',border:'1px solid rgba(34,211,238,.2)'},
  searchWrap:{position:'relative',marginBottom:'12px'},
  search:{width:'100%',background:'#111c2e',border:'1px solid rgba(255,255,255,0.06)',borderRadius:'10px',padding:'9px 12px 9px 34px',color:'#f0f6ff',fontSize:'12.5px',outline:'none',transition:'border-color .2s, box-shadow .2s',boxSizing:'border-box'},
  clearBtn:{position:'absolute',right:'10px',top:'50%',transform:'translateY(-50%)',background:'none',border:'none',cursor:'pointer',color:'#3d5470',display:'flex',alignItems:'center'},
  tabs:{display:'flex',borderBottom:'1px solid rgba(255,255,255,0.06)'},
  tab:{flex:1,padding:'10px 0',background:'none',border:'none',fontSize:'12px',fontWeight:'600',color:'#3d5470',cursor:'pointer',position:'relative',transition:'color .15s'},
  tabActive:{color:'#22d3ee'},
  tabBar:{position:'absolute',bottom:0,left:'15%',right:'15%',height:'2px',background:'#22d3ee',borderRadius:'2px 2px 0 0'},
  list:{flex:1,overflowY:'auto',padding:'6px 8px'},
  empty:{display:'flex',flexDirection:'column',alignItems:'center',justifyContent:'center',height:'180px',color:'#1e3048',fontSize:'13px'},
  item:{width:'100%',background:'transparent',border:'none',borderRadius:'10px',padding:'10px 10px',display:'flex',alignItems:'center',gap:'11px',cursor:'pointer',transition:'background .12s',textAlign:'left',marginBottom:'2px',position:'relative'},
  itemActive:{background:'#152235'},
  activeBar:{position:'absolute',left:0,top:'20%',bottom:'20%',width:'3px',background:'#22d3ee',borderRadius:'0 3px 3px 0'},
  av:{width:'42px',height:'42px',borderRadius:'50%',display:'flex',alignItems:'center',justifyContent:'center',fontSize:'13px',fontWeight:'700',color:'white',flexShrink:0},
  aiDot:{position:'absolute',bottom:'1px',right:'1px',width:'11px',height:'11px',borderRadius:'50%',background:'#22d3ee',border:'2px solid #0d1420'},
  body:{flex:1,minWidth:0},
  itemName:{fontSize:'13px',fontWeight:'600',color:'#f0f6ff',whiteSpace:'nowrap',overflow:'hidden',textOverflow:'ellipsis',marginBottom:'2px'},
  preview:{fontSize:'11.5px',color:'#8ba4c0',whiteSpace:'nowrap',overflow:'hidden',textOverflow:'ellipsis'},
  right:{display:'flex',flexDirection:'column',alignItems:'flex-end',gap:'5px',flexShrink:0},
  time:{fontSize:'10px',color:'#3d5470',fontFamily:"'DM Mono',monospace"},
  unread:{background:'#22d3ee',color:'#020617',fontSize:'9.5px',fontWeight:'800',minWidth:'18px',height:'18px',padding:'0 5px',borderRadius:'9px',display:'flex',alignItems:'center',justifyContent:'center'},
  aiChip:{background:'rgba(34,211,238,0.1)',color:'#22d3ee',fontSize:'9px',fontWeight:'700',padding:'1px 5px',borderRadius:'4px',border:'1px solid rgba(34,211,238,.2)'},
};
