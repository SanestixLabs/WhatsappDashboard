import React from 'react';
export function EmptyState() {
  return (
    <div style={s.root}>
      <div style={s.glow}/>
      <div style={s.icon}><WaIcon/></div>
      <h3 style={s.title}>Sanestix Flow</h3>
      <p style={s.sub}>Select a conversation to start,<br/>or wait for incoming messages.</p>
      <div style={s.hints}>
        {[['AI auto-replies to customers','bot'],['Toggle AI off to reply manually','toggle'],['Messages update in real-time','live']].map(([t])=>(
          <div key={t} style={s.hint}><div style={s.dot}/><span style={s.hintText}>{t}</span></div>
        ))}
      </div>
    </div>
  );
}
const WaIcon=()=><svg width="40" height="40" viewBox="0 0 24 24" fill="none"><path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51a6.08 6.08 0 00-.57-.01c-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347z" fill="rgba(34,211,238,0.4)"/><path d="M5.077 18.347l.892-3.244a8.357 8.357 0 01-1.12-4.232C4.852 6.26 8.113 3 12.124 3c1.948.001 3.778.76 5.151 2.138a7.247 7.247 0 012.124 5.155c-.002 4.012-3.263 7.272-7.272 7.272a7.266 7.266 0 01-3.475-.883l-3.575.865z" stroke="rgba(34,211,238,0.4)" strokeWidth="1.5" fill="none"/></svg>;
const s={
  root:{flex:1,display:'flex',flexDirection:'column',alignItems:'center',justifyContent:'center',background:'#080c12',position:'relative',overflow:'hidden'},
  glow:{position:'absolute',width:'400px',height:'400px',borderRadius:'50%',background:'radial-gradient(circle,rgba(34,211,238,0.04) 0%,transparent 70%)',pointerEvents:'none'},
  icon:{width:'76px',height:'76px',borderRadius:'22px',background:'rgba(34,211,238,0.06)',border:'1px solid rgba(34,211,238,0.1)',display:'flex',alignItems:'center',justifyContent:'center',marginBottom:'16px',position:'relative',zIndex:1},
  title:{fontSize:'18px',fontWeight:'700',color:'#1e3048',letterSpacing:'-.3px',marginBottom:'8px',position:'relative',zIndex:1},
  sub:{fontSize:'13px',color:'#1e3048',lineHeight:1.7,textAlign:'center',marginBottom:'24px',position:'relative',zIndex:1},
  hints:{display:'flex',flexDirection:'column',gap:'10px',position:'relative',zIndex:1},
  hint:{display:'flex',alignItems:'center',gap:'10px'},
  dot:{width:'5px',height:'5px',borderRadius:'50%',background:'#1e3048',flexShrink:0},
  hintText:{fontSize:'12px',color:'#1e3048'},
};
